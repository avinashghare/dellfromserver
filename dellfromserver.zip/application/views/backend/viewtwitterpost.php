<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                Twitter Posts
            </header>
            <div class="masonryposts"></div>
            
            </div>
        </section>
        <script>
            generatemasonry('<?php echo $base_url;?>',"<?php echo base_url();?>",'twitter');
            
        </script>
    </div>
</div>
