<?php 
echo file_get_contents("http://dellcampassador.com/index.php/cron/socialupdate"); 
?>